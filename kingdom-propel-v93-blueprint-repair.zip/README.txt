KINGDOM PROPEL V93 — BLUEPRINT REPAIR

This is a small correction package for the V92 consolidated update.
It restores the approved Propel Digital Ministry Blueprint styling and behavior.

Upload the contents of this folder into the repository root.
When GitHub asks about replacing existing files, allow it to replace these three files:

demo-blueprint/index.html
demo-blueprint/blueprint.css
demo-blueprint/blueprint.js

No other site files need to be removed or replaced.

After Netlify finishes deploying, refresh the Blueprint page. If the old version remains visible, force-refresh the page once so the browser discards its cached stylesheet and script.
